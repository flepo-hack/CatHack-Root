CAT PROMPT - Made by Flepo v1.0
=================================
Requirements:
- Rooted Android with Termux or Kali NetHunter
- Packages: aircrack-ng, iw, jq, curl

Installation:
1. pkg install root-repo
2. pkg install aircrack-ng iw jq curl -y
3. unzip rootcatprompt.zip
4. cd rootcatprompt
5. chmod +x rootcat.sh
6. ./rootcat.sh

Note: rockyou.txt included is short sample. Replace with full version at:
/usr/share/wordlists/rockyou.txt
